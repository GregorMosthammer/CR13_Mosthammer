<?php

/* event/details.html.twig */
class __TwigTemplate_49c432f3c814a2941b882f14a7d855c6d194dbab2b321772dfc037a5682aeffb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9893d50f75a37216d1b248ccb4568ea4c4bb9d048acd56a0d71195a017149a5a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9893d50f75a37216d1b248ccb4568ea4c4bb9d048acd56a0d71195a017149a5a->enter($__internal_9893d50f75a37216d1b248ccb4568ea4c4bb9d048acd56a0d71195a017149a5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/details.html.twig"));

        $__internal_feadf5c970dd0e3f203f465786438fe32835e7ac5525923a39e40b154774829c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_feadf5c970dd0e3f203f465786438fe32835e7ac5525923a39e40b154774829c->enter($__internal_feadf5c970dd0e3f203f465786438fe32835e7ac5525923a39e40b154774829c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9893d50f75a37216d1b248ccb4568ea4c4bb9d048acd56a0d71195a017149a5a->leave($__internal_9893d50f75a37216d1b248ccb4568ea4c4bb9d048acd56a0d71195a017149a5a_prof);

        
        $__internal_feadf5c970dd0e3f203f465786438fe32835e7ac5525923a39e40b154774829c->leave($__internal_feadf5c970dd0e3f203f465786438fe32835e7ac5525923a39e40b154774829c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_37c958af72a7d8199dbd46025a8698c3e1e59a5186a1b1b4a00a5eeffff65b84 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37c958af72a7d8199dbd46025a8698c3e1e59a5186a1b1b4a00a5eeffff65b84->enter($__internal_37c958af72a7d8199dbd46025a8698c3e1e59a5186a1b1b4a00a5eeffff65b84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_48c555f963f897a3740fbbd1286f78f814febbcf84ef44728b5b49d6491a7ae2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48c555f963f897a3740fbbd1286f78f814febbcf84ef44728b5b49d6491a7ae2->enter($__internal_48c555f963f897a3740fbbd1286f78f814febbcf84ef44728b5b49d6491a7ae2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
        <a class=\"btn btn-default\" href=\"/\">Back to Todos</a>

        <hr>

        <h2 class=\"page-header\">";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["todo"] ?? $this->getContext($context, "todo")), "name", array()), "html", null, true);
        echo "</h2>





";
        
        $__internal_48c555f963f897a3740fbbd1286f78f814febbcf84ef44728b5b49d6491a7ae2->leave($__internal_48c555f963f897a3740fbbd1286f78f814febbcf84ef44728b5b49d6491a7ae2_prof);

        
        $__internal_37c958af72a7d8199dbd46025a8698c3e1e59a5186a1b1b4a00a5eeffff65b84->leave($__internal_37c958af72a7d8199dbd46025a8698c3e1e59a5186a1b1b4a00a5eeffff65b84_prof);

    }

    public function getTemplateName()
    {
        return "event/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

        <a class=\"btn btn-default\" href=\"/\">Back to Todos</a>

        <hr>

        <h2 class=\"page-header\">{{todo.name}}</h2>





{% endblock %}", "event/details.html.twig", "C:\\xampp\\htdocs\\event\\app\\Resources\\views\\event\\details.html.twig");
    }
}
