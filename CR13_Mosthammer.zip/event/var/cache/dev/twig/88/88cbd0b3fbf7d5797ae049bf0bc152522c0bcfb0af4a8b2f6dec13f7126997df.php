<?php

/* event/index.html.twig */
class __TwigTemplate_df5409164cd49ebc3bba7f7e9ede4dfb2d3b05509f22b4d1c1ca33fe5cea1952 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20583558ca2ec905ed24140c51478d6ef666cc9559e8608763913b7a397be52a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_20583558ca2ec905ed24140c51478d6ef666cc9559e8608763913b7a397be52a->enter($__internal_20583558ca2ec905ed24140c51478d6ef666cc9559e8608763913b7a397be52a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $__internal_cda7b9989dd34918c4671994382badf88d0423596bd302109941be5c2746434c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cda7b9989dd34918c4671994382badf88d0423596bd302109941be5c2746434c->enter($__internal_cda7b9989dd34918c4671994382badf88d0423596bd302109941be5c2746434c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_20583558ca2ec905ed24140c51478d6ef666cc9559e8608763913b7a397be52a->leave($__internal_20583558ca2ec905ed24140c51478d6ef666cc9559e8608763913b7a397be52a_prof);

        
        $__internal_cda7b9989dd34918c4671994382badf88d0423596bd302109941be5c2746434c->leave($__internal_cda7b9989dd34918c4671994382badf88d0423596bd302109941be5c2746434c_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_37b7b4f611332c7a06a2c9b5f9b7e4de20d3e4e0d39cb2992fa26df16adb5544 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37b7b4f611332c7a06a2c9b5f9b7e4de20d3e4e0d39cb2992fa26df16adb5544->enter($__internal_37b7b4f611332c7a06a2c9b5f9b7e4de20d3e4e0d39cb2992fa26df16adb5544_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_008332ec646efcb7c5bae94ae1e44bf2882cec83b6571670fbfe8c770fa2440c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_008332ec646efcb7c5bae94ae1e44bf2882cec83b6571670fbfe8c770fa2440c->enter($__internal_008332ec646efcb7c5bae94ae1e44bf2882cec83b6571670fbfe8c770fa2440c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "
        

 <h2 class=\"page-header\"> List of Events </h2>
 <table class=\"table table-striped\">



";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["todos"] ?? $this->getContext($context, "todos")));
        foreach ($context['_seq'] as $context["_key"] => $context["todo"]) {
            // line 12
            echo "
    <tbody>

        <tr>

            <th scope=\"row\"><img src=\"";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "image", array()), "html", null, true);
            echo "\">
                    <br> ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "name", array()), "html", null, true);
            echo "
            </th>

            <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "time", array()), "html", null, true);
            echo "</td>
           

            <td> <a href=\"/event/details/";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-success\">View</a>
            <a href=\"/event/edit/";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-default\">Edit</a>
            <a href=\"/event/delete/";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["todo"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>        

            </td>

        </tr> 

";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['todo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "
    </tbody>



";
        
        $__internal_008332ec646efcb7c5bae94ae1e44bf2882cec83b6571670fbfe8c770fa2440c->leave($__internal_008332ec646efcb7c5bae94ae1e44bf2882cec83b6571670fbfe8c770fa2440c_prof);

        
        $__internal_37b7b4f611332c7a06a2c9b5f9b7e4de20d3e4e0d39cb2992fa26df16adb5544->leave($__internal_37b7b4f611332c7a06a2c9b5f9b7e4de20d3e4e0d39cb2992fa26df16adb5544_prof);

    }

    public function getTemplateName()
    {
        return "event/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 33,  94 => 26,  90 => 25,  86 => 24,  80 => 21,  74 => 18,  70 => 17,  63 => 12,  59 => 11,  49 => 3,  40 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}
{% block body %}

        

 <h2 class=\"page-header\"> List of Events </h2>
 <table class=\"table table-striped\">



{% for todo in todos %}

    <tbody>

        <tr>

            <th scope=\"row\"><img src=\"{{todo.image}}\">
                    <br> {{todo.name}}
            </th>

            <td>{{todo.time}}</td>
           

            <td> <a href=\"/event/details/{{todo.id}}\" class=\"btn btn-success\">View</a>
            <a href=\"/event/edit/{{todo.id}}\" class=\"btn btn-default\">Edit</a>
            <a href=\"/event/delete/{{todo.id}}\" class=\"btn btn-danger\">Delete</a>        

            </td>

        </tr> 

{% endfor %}

    </tbody>



{% endblock %}", "event/index.html.twig", "C:\\xampp\\htdocs\\event\\app\\Resources\\views\\event\\index.html.twig");
    }
}
