<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_5bd7f8a780af153f7b032cdcf8ff8bed527ab6abfb102758ecf7625f9382938d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0338a0e259d4fa230c0a8a904d5cec6e5151c314dd8a15aafe26a601a812750b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0338a0e259d4fa230c0a8a904d5cec6e5151c314dd8a15aafe26a601a812750b->enter($__internal_0338a0e259d4fa230c0a8a904d5cec6e5151c314dd8a15aafe26a601a812750b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $__internal_f1b77f04ac7f6872604dd0a7cfc4846b5c6610224a8a078ddc92063ef61f5989 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f1b77f04ac7f6872604dd0a7cfc4846b5c6610224a8a078ddc92063ef61f5989->enter($__internal_f1b77f04ac7f6872604dd0a7cfc4846b5c6610224a8a078ddc92063ef61f5989_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0338a0e259d4fa230c0a8a904d5cec6e5151c314dd8a15aafe26a601a812750b->leave($__internal_0338a0e259d4fa230c0a8a904d5cec6e5151c314dd8a15aafe26a601a812750b_prof);

        
        $__internal_f1b77f04ac7f6872604dd0a7cfc4846b5c6610224a8a078ddc92063ef61f5989->leave($__internal_f1b77f04ac7f6872604dd0a7cfc4846b5c6610224a8a078ddc92063ef61f5989_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_93f0187aa9026590cfce918cc4aac7fa1abb64036c8dd69a7e201a9f4c083f68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_93f0187aa9026590cfce918cc4aac7fa1abb64036c8dd69a7e201a9f4c083f68->enter($__internal_93f0187aa9026590cfce918cc4aac7fa1abb64036c8dd69a7e201a9f4c083f68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_9178ce97874d1af703480f4e8a4b049efe255cd43de1c7b2f9c9957ca3b9f160 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9178ce97874d1af703480f4e8a4b049efe255cd43de1c7b2f9c9957ca3b9f160->enter($__internal_9178ce97874d1af703480f4e8a4b049efe255cd43de1c7b2f9c9957ca3b9f160_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
";
        
        $__internal_9178ce97874d1af703480f4e8a4b049efe255cd43de1c7b2f9c9957ca3b9f160->leave($__internal_9178ce97874d1af703480f4e8a4b049efe255cd43de1c7b2f9c9957ca3b9f160_prof);

        
        $__internal_93f0187aa9026590cfce918cc4aac7fa1abb64036c8dd69a7e201a9f4c083f68->leave($__internal_93f0187aa9026590cfce918cc4aac7fa1abb64036c8dd69a7e201a9f4c083f68_prof);

    }

    // line 136
    public function block_title($context, array $blocks = array())
    {
        $__internal_f26571f0f9bb8455925d3bf6fed57b3ea858dda9640c1601b5d69782c27f4e2e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f26571f0f9bb8455925d3bf6fed57b3ea858dda9640c1601b5d69782c27f4e2e->enter($__internal_f26571f0f9bb8455925d3bf6fed57b3ea858dda9640c1601b5d69782c27f4e2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_a7f9a5bbbd81545f112bcc27d33a0aa96c48f2218b9d69ba8a3af806dff9084f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7f9a5bbbd81545f112bcc27d33a0aa96c48f2218b9d69ba8a3af806dff9084f->enter($__internal_a7f9a5bbbd81545f112bcc27d33a0aa96c48f2218b9d69ba8a3af806dff9084f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 137
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_a7f9a5bbbd81545f112bcc27d33a0aa96c48f2218b9d69ba8a3af806dff9084f->leave($__internal_a7f9a5bbbd81545f112bcc27d33a0aa96c48f2218b9d69ba8a3af806dff9084f_prof);

        
        $__internal_f26571f0f9bb8455925d3bf6fed57b3ea858dda9640c1601b5d69782c27f4e2e->leave($__internal_f26571f0f9bb8455925d3bf6fed57b3ea858dda9640c1601b5d69782c27f4e2e_prof);

    }

    // line 140
    public function block_body($context, array $blocks = array())
    {
        $__internal_a441b752c64a89689b07e56acb93e5e4c52df9e8e4d26d9e9c020fababa50fc8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a441b752c64a89689b07e56acb93e5e4c52df9e8e4d26d9e9c020fababa50fc8->enter($__internal_a441b752c64a89689b07e56acb93e5e4c52df9e8e4d26d9e9c020fababa50fc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fd3e1a9f32696cbe6f4456e4fd8aa64d1c94cac237254ee56b1f9d48b21551da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fd3e1a9f32696cbe6f4456e4fd8aa64d1c94cac237254ee56b1f9d48b21551da->enter($__internal_fd3e1a9f32696cbe6f4456e4fd8aa64d1c94cac237254ee56b1f9d48b21551da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 141
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 141)->display($context);
        
        $__internal_fd3e1a9f32696cbe6f4456e4fd8aa64d1c94cac237254ee56b1f9d48b21551da->leave($__internal_fd3e1a9f32696cbe6f4456e4fd8aa64d1c94cac237254ee56b1f9d48b21551da_prof);

        
        $__internal_a441b752c64a89689b07e56acb93e5e4c52df9e8e4d26d9e9c020fababa50fc8->leave($__internal_a441b752c64a89689b07e56acb93e5e4c52df9e8e4d26d9e9c020fababa50fc8_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  226 => 141,  217 => 140,  200 => 137,  191 => 136,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <style>
        .sf-reset .traces {
            padding-bottom: 14px;
        }
        .sf-reset .traces li {
            font-size: 12px;
            color: #868686;
            padding: 5px 4px;
            list-style-type: decimal;
            margin-left: 20px;
        }
        .sf-reset #logs .traces li.error {
            font-style: normal;
            color: #AA3333;
            background: #f9ecec;
        }
        .sf-reset #logs .traces li.warning {
            font-style: normal;
            background: #ffcc00;
        }
        /* fix for Opera not liking empty <li> */
        .sf-reset .traces li:after {
            content: \"\\00A0\";
        }
        .sf-reset .trace {
            border: 1px solid #D3D3D3;
            padding: 10px;
            overflow: auto;
            margin: 10px 0 20px;
        }
        .sf-reset .block-exception {
            -moz-border-radius: 16px;
            -webkit-border-radius: 16px;
            border-radius: 16px;
            margin-bottom: 20px;
            background-color: #f6f6f6;
            border: 1px solid #dfdfdf;
            padding: 30px 28px;
            word-wrap: break-word;
            overflow: hidden;
        }
        .sf-reset .block-exception div {
            color: #313131;
            font-size: 10px;
        }
        .sf-reset .block-exception-detected .illustration-exception,
        .sf-reset .block-exception-detected .text-exception {
            float: left;
        }
        .sf-reset .block-exception-detected .illustration-exception {
            width: 152px;
        }
        .sf-reset .block-exception-detected .text-exception {
            width: 670px;
            padding: 30px 44px 24px 46px;
            position: relative;
        }
        .sf-reset .text-exception .open-quote,
        .sf-reset .text-exception .close-quote {
            font-family: Arial, Helvetica, sans-serif;
            position: absolute;
            color: #C9C9C9;
            font-size: 8em;
        }
        .sf-reset .open-quote {
            top: 0;
            left: 0;
        }
        .sf-reset .close-quote {
            bottom: -0.5em;
            right: 50px;
        }
        .sf-reset .block-exception p {
            font-family: Arial, Helvetica, sans-serif;
        }
        .sf-reset .block-exception p a,
        .sf-reset .block-exception p a:hover {
            color: #565656;
        }
        .sf-reset .logs h2 {
            float: left;
            width: 654px;
        }
        .sf-reset .error-count, .sf-reset .support {
            float: right;
            width: 170px;
            text-align: right;
        }
        .sf-reset .error-count span {
             display: inline-block;
             background-color: #aacd4e;
             -moz-border-radius: 6px;
             -webkit-border-radius: 6px;
             border-radius: 6px;
             padding: 4px;
             color: white;
             margin-right: 2px;
             font-size: 11px;
             font-weight: bold;
        }

        .sf-reset .support a {
            display: inline-block;
            -moz-border-radius: 6px;
            -webkit-border-radius: 6px;
            border-radius: 6px;
            padding: 4px;
            color: #000000;
            margin-right: 2px;
            font-size: 11px;
            font-weight: bold;
        }

        .sf-reset .toggle {
            vertical-align: middle;
        }
        .sf-reset .linked ul,
        .sf-reset .linked li {
            display: inline;
        }
        .sf-reset #output-content {
            color: #000;
            font-size: 12px;
        }
        .sf-reset #traces-text pre {
            white-space: pre;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "C:\\xampp\\htdocs\\event\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception_full.html.twig");
    }
}
