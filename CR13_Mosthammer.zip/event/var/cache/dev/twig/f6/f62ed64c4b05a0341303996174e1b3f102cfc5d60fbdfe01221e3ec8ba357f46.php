<?php

/* event/create.html.twig */
class __TwigTemplate_444071142fa9448935812d96f348a41dd47727965e6138767d63d49806b6d4cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8fab1fcddcaccac0ceba8e679adf924f0924e864d9d79ab6d20bdde80374d6ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8fab1fcddcaccac0ceba8e679adf924f0924e864d9d79ab6d20bdde80374d6ef->enter($__internal_8fab1fcddcaccac0ceba8e679adf924f0924e864d9d79ab6d20bdde80374d6ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/create.html.twig"));

        $__internal_aeb64411042b94271de3fb0388334a06df1c04276db5ebc94b87eaa31a2c7dad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aeb64411042b94271de3fb0388334a06df1c04276db5ebc94b87eaa31a2c7dad->enter($__internal_aeb64411042b94271de3fb0388334a06df1c04276db5ebc94b87eaa31a2c7dad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8fab1fcddcaccac0ceba8e679adf924f0924e864d9d79ab6d20bdde80374d6ef->leave($__internal_8fab1fcddcaccac0ceba8e679adf924f0924e864d9d79ab6d20bdde80374d6ef_prof);

        
        $__internal_aeb64411042b94271de3fb0388334a06df1c04276db5ebc94b87eaa31a2c7dad->leave($__internal_aeb64411042b94271de3fb0388334a06df1c04276db5ebc94b87eaa31a2c7dad_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0fdd2f7571535c19f1187e38a10e97e8083ac477581c0551afc5c3a7c11d1650 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0fdd2f7571535c19f1187e38a10e97e8083ac477581c0551afc5c3a7c11d1650->enter($__internal_0fdd2f7571535c19f1187e38a10e97e8083ac477581c0551afc5c3a7c11d1650_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a624a7d47ad9015ee8848ab2cdc4852e6d8b149643b6d09cc084c7e620d60be3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a624a7d47ad9015ee8848ab2cdc4852e6d8b149643b6d09cc084c7e620d60be3->enter($__internal_a624a7d47ad9015ee8848ab2cdc4852e6d8b149643b6d09cc084c7e620d60be3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<h2 class=\"page-header\">Add Todo</h2>

";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "

";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "

";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

";
        
        $__internal_a624a7d47ad9015ee8848ab2cdc4852e6d8b149643b6d09cc084c7e620d60be3->leave($__internal_a624a7d47ad9015ee8848ab2cdc4852e6d8b149643b6d09cc084c7e620d60be3_prof);

        
        $__internal_0fdd2f7571535c19f1187e38a10e97e8083ac477581c0551afc5c3a7c11d1650->leave($__internal_0fdd2f7571535c19f1187e38a10e97e8083ac477581c0551afc5c3a7c11d1650_prof);

    }

    public function getTemplateName()
    {
        return "event/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 11,  59 => 9,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

<h2 class=\"page-header\">Add Todo</h2>

{{form_start(form)}}

{{form_widget(form)}}

{{form_end(form)}}

{% endblock %}", "event/create.html.twig", "C:\\xampp\\htdocs\\event\\app\\Resources\\views\\event\\create.html.twig");
    }
}
