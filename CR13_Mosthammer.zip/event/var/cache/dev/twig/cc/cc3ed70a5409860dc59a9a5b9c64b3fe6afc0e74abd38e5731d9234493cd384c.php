<?php

/* event/edit.html.twig */
class __TwigTemplate_83870d9f456b2b4de246f1a28e12d7ed4338167997720d978a64ffc6af35b254 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "event/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f12012c49ddece20dab7c2abdf335b7bbab777a05848b07d619a5a750100ccd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f12012c49ddece20dab7c2abdf335b7bbab777a05848b07d619a5a750100ccd->enter($__internal_0f12012c49ddece20dab7c2abdf335b7bbab777a05848b07d619a5a750100ccd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/edit.html.twig"));

        $__internal_09d0a18a305e0300e2d8ab8c3cf10690179fac7936a690aaf82121ad3ae28beb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09d0a18a305e0300e2d8ab8c3cf10690179fac7936a690aaf82121ad3ae28beb->enter($__internal_09d0a18a305e0300e2d8ab8c3cf10690179fac7936a690aaf82121ad3ae28beb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "event/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0f12012c49ddece20dab7c2abdf335b7bbab777a05848b07d619a5a750100ccd->leave($__internal_0f12012c49ddece20dab7c2abdf335b7bbab777a05848b07d619a5a750100ccd_prof);

        
        $__internal_09d0a18a305e0300e2d8ab8c3cf10690179fac7936a690aaf82121ad3ae28beb->leave($__internal_09d0a18a305e0300e2d8ab8c3cf10690179fac7936a690aaf82121ad3ae28beb_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_631270809b2142b07d3691b8cf03d1b7dd2cbf97e01644f4a9d7c8d16cc57b82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_631270809b2142b07d3691b8cf03d1b7dd2cbf97e01644f4a9d7c8d16cc57b82->enter($__internal_631270809b2142b07d3691b8cf03d1b7dd2cbf97e01644f4a9d7c8d16cc57b82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ad02dafe7339599f2feb5fd02d1b44eb26b4e7db9138c7d6cdf98db99bec234b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad02dafe7339599f2feb5fd02d1b44eb26b4e7db9138c7d6cdf98db99bec234b->enter($__internal_ad02dafe7339599f2feb5fd02d1b44eb26b4e7db9138c7d6cdf98db99bec234b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<h2 class=\"page-header\">Edit Todo</h2>

";
        // line 7
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "

";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? $this->getContext($context, "form")), 'widget');
        echo "

";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

";
        
        $__internal_ad02dafe7339599f2feb5fd02d1b44eb26b4e7db9138c7d6cdf98db99bec234b->leave($__internal_ad02dafe7339599f2feb5fd02d1b44eb26b4e7db9138c7d6cdf98db99bec234b_prof);

        
        $__internal_631270809b2142b07d3691b8cf03d1b7dd2cbf97e01644f4a9d7c8d16cc57b82->leave($__internal_631270809b2142b07d3691b8cf03d1b7dd2cbf97e01644f4a9d7c8d16cc57b82_prof);

    }

    public function getTemplateName()
    {
        return "event/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 11,  59 => 9,  54 => 7,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

<h2 class=\"page-header\">Edit Todo</h2>

{{form_start(form)}}

{{form_widget(form)}}

{{form_end(form)}}

{% endblock %}", "event/edit.html.twig", "C:\\xampp\\htdocs\\event\\app\\Resources\\views\\event\\edit.html.twig");
    }
}
