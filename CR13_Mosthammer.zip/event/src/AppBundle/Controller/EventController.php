<?php
namespace AppBundle\Controller;
use AppBundle\Entity\Event;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

class EventController extends Controller

{

    /**

     * @Route("/", name="todo_list")

     */

    public function listAction(){

        $todos = $this->getDoctrine()->getRepository('AppBundle:Event')->findAll();

        // replace this example code with whatever you need

        return $this->render('event/index.html.twig', array('todos'=>$todos));

    }

     /**

     * @Route("/event/create", name="todo_create")

     */

    public function createAction(Request $request){

        $todo = new Event;

        $form = $this->createFormBuilder($todo)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
      ->add('date', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('time', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
           ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
           ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
           ->add('person', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
             ->add('URL', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
             ->add('Type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))


    ->add('save', SubmitType::class, array('label'=> 'Create event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-bottom:15px')))

        ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){

            //fetching data

            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $time = $form['time']->getData();
            $description = $form['description']->getData();
            $image = $form['image']->getData();
            $capacity = $form['capacity']->getData();
            $phone = $form['phone']->getData();
            $person = $form['person']->getData();
            $address = $form['address']->getData();
            $uRL = $form['URL']->getData();
            $type = $form['Type']->getData();

            $todo->setName($name);
            $todo->setDate($date);
            $todo->setTime($time);
            $todo->setDescription($description);
            $todo->setImage($image);
            $todo->setCapacity($capacity);
            $todo->setPhone($phone);
            $todo->setPerson($person);
            $todo->setAddress($address);
            $todo->setURL($uRL);
            $todo->setType($type);

            $em = $this->getDoctrine()->getManager();

            $em->persist($todo);

            $em->flush();

            $this->addFlash(

                    'notice',

                    'Event Added'

                    );

            return $this->redirectToRoute('todo_list');

        }

        // replace this example code with whatever you need

        return $this->render('event/create.html.twig', array('form' => $form->createView()));

    }

/**

     * @Route("/event/edit/{id}", name="todo_edit")

     */

    public function editAction( $id, Request $request){

    $todo = $this->getDoctrine()->getRepository('AppBundle:Event')->find($id);


            $todo->setName($todo->getName());

          $form = $this->createFormBuilder($todo)->add('name', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
      ->add('date', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
        ->add('time', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
           ->add('description', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('image', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
           ->add('capacity', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
          ->add('phone', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
           ->add('person', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
            ->add('address', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
             ->add('URL', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))
             ->add('Type', TextType::class, array('attr' => array('class'=> 'form-control', 'style'=>'margin-bottom:15px')))

    ->add('save', SubmitType::class, array('label'=> 'Update Event', 'attr' => array('class'=> 'btn-primary', 'style'=>'margin-botton:15px')))

        ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){

            //fetching data

            $name = $form['name']->getData();
            $date = $form['date']->getData();
            $time = $form['time']->getData();
            $description = $form['description']->getData();
            $image = $form['image']->getData();
            $capacity = $form['capacity']->getData();
            $phone = $form['phone']->getData();
            $person = $form['person']->getData();
            $address = $form['address']->getData();
            $uRL = $form['URL']->getData();
            $type = $form['Type']->getData();

            $em = $this->getDoctrine()->getManager();

            $todo = $em->getRepository('AppBundle:Event')->find($id);

            $todo->setName($name);
            $todo->setDate($date);
            $todo->setTime($time);
            $todo->setDescription($description);
            $todo->setImage($image);
            $todo->setCapacity($capacity);
            $todo->setPhone($phone);
            $todo->setPerson($person);
            $todo->setAddress($address);
            $todo->setURL($uRL);
            $todo->setType($type);

            $em->flush();

            $this->addFlash(

                    'notice',

                    'Event Updated'

                    );

            return $this->redirectToRoute('todo_list');

        }

        return $this->render('event/edit.html.twig', array('todo' => $todo, 'form' => $form->createView()));

    }

    /**
     * @Route("/event/delete/{id}", name="todo_delete")
     */
    public function deleteAction($id){
                 $em = $this->getDoctrine()->getManager();
            $todo = $em->getRepository('AppBundle:Event')->find($id);
            $em->remove($todo);
             $em->flush();
            $this->addFlash(
                    'notice',
                    'event removed'
                    );
             return $this->redirectToRoute('todo_list');
    }
    

     /**

     * @Route("/event/details/{id}", name="todo_details")

     */

public function detailsAction($id){

                $todo = $this->getDoctrine()->getRepository('AppBundle:Event')->find($id);

        return $this->render('event/details.html.twig', array('todo' => $todo));

    }

}



