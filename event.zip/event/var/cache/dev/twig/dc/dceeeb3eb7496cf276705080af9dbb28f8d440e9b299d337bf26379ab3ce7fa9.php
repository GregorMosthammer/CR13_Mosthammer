<?php

/* base.html.twig */
class __TwigTemplate_551c2a089b13ddf4e0ac2282d0eb2712a2ea82e32b4a08ce8ba8a82a0817cbe0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_004e649cb6fcefdda81d78ef0819c521362f27d8203cde55bb4c2bbed406c9fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_004e649cb6fcefdda81d78ef0819c521362f27d8203cde55bb4c2bbed406c9fc->enter($__internal_004e649cb6fcefdda81d78ef0819c521362f27d8203cde55bb4c2bbed406c9fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_c69a4f1a1585ea5141b9001aa0b0af9e492ec2df8c6e29b34297d3df28c03ce6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c69a4f1a1585ea5141b9001aa0b0af9e492ec2df8c6e29b34297d3df28c03ce6->enter($__internal_c69a4f1a1585ea5141b9001aa0b0af9e492ec2df8c6e29b34297d3df28c03ce6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\"> ";
        // line 10
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />


<link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/stylesheet.css"), "html", null, true);
        echo "\" />

        <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("stylesheet.css"), "html", null, true);
        echo "\" />
    
</head>

<body>
    <nav class=\"navbar navbar-default\">
        <div class=\"container\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">Event List</a>
            </div>
            <div id=\"navbar\" class=\"collapse navbar-collapse\">
                <ul class=\"nav navbar-nav\">
                    <li><a href=\"/\">Home</a></li>
                    <li><a href=\"/event/create\">Add an event</a></li>

                   
                   

                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
    </nav>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                ";
        // line 48
        $this->displayBlock('body', $context, $blocks);
        // line 49
        echo "            </div>
        </div>
    </div>
    <!-- /.container -->
    ";
        // line 53
        $this->displayBlock('javascripts', $context, $blocks);
        // line 54
        echo "</body>

</html>";
        
        $__internal_004e649cb6fcefdda81d78ef0819c521362f27d8203cde55bb4c2bbed406c9fc->leave($__internal_004e649cb6fcefdda81d78ef0819c521362f27d8203cde55bb4c2bbed406c9fc_prof);

        
        $__internal_c69a4f1a1585ea5141b9001aa0b0af9e492ec2df8c6e29b34297d3df28c03ce6->leave($__internal_c69a4f1a1585ea5141b9001aa0b0af9e492ec2df8c6e29b34297d3df28c03ce6_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_04cb2e3209a6931db6e8a6fa8353e8e07efe2265a68fcc00e63e940992fa390a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04cb2e3209a6931db6e8a6fa8353e8e07efe2265a68fcc00e63e940992fa390a->enter($__internal_04cb2e3209a6931db6e8a6fa8353e8e07efe2265a68fcc00e63e940992fa390a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_4470c2e10e3040f45ae2339f529b221cdda4310a18959ec22676f9e8dd2f7e84 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4470c2e10e3040f45ae2339f529b221cdda4310a18959ec22676f9e8dd2f7e84->enter($__internal_4470c2e10e3040f45ae2339f529b221cdda4310a18959ec22676f9e8dd2f7e84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Event!";
        
        $__internal_4470c2e10e3040f45ae2339f529b221cdda4310a18959ec22676f9e8dd2f7e84->leave($__internal_4470c2e10e3040f45ae2339f529b221cdda4310a18959ec22676f9e8dd2f7e84_prof);

        
        $__internal_04cb2e3209a6931db6e8a6fa8353e8e07efe2265a68fcc00e63e940992fa390a->leave($__internal_04cb2e3209a6931db6e8a6fa8353e8e07efe2265a68fcc00e63e940992fa390a_prof);

    }

    // line 10
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f0bbe2781e646ed721809cfc7d18d35117f255f6899dd924a8c2160891e643f5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f0bbe2781e646ed721809cfc7d18d35117f255f6899dd924a8c2160891e643f5->enter($__internal_f0bbe2781e646ed721809cfc7d18d35117f255f6899dd924a8c2160891e643f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_dd2e634ba7ec90204b36323a3c06f80713aeae1193f05a3541cb0f544f6ff69f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd2e634ba7ec90204b36323a3c06f80713aeae1193f05a3541cb0f544f6ff69f->enter($__internal_dd2e634ba7ec90204b36323a3c06f80713aeae1193f05a3541cb0f544f6ff69f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_dd2e634ba7ec90204b36323a3c06f80713aeae1193f05a3541cb0f544f6ff69f->leave($__internal_dd2e634ba7ec90204b36323a3c06f80713aeae1193f05a3541cb0f544f6ff69f_prof);

        
        $__internal_f0bbe2781e646ed721809cfc7d18d35117f255f6899dd924a8c2160891e643f5->leave($__internal_f0bbe2781e646ed721809cfc7d18d35117f255f6899dd924a8c2160891e643f5_prof);

    }

    // line 48
    public function block_body($context, array $blocks = array())
    {
        $__internal_fcea21d6f97a4e2c829c7b3ab01d8e028b819be0bbfbd7ab29c1706bdcf4c667 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fcea21d6f97a4e2c829c7b3ab01d8e028b819be0bbfbd7ab29c1706bdcf4c667->enter($__internal_fcea21d6f97a4e2c829c7b3ab01d8e028b819be0bbfbd7ab29c1706bdcf4c667_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a985c7186a9e61da6580a98dbb7b4c1044644528f94664441d85cb21b5068fb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a985c7186a9e61da6580a98dbb7b4c1044644528f94664441d85cb21b5068fb4->enter($__internal_a985c7186a9e61da6580a98dbb7b4c1044644528f94664441d85cb21b5068fb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_a985c7186a9e61da6580a98dbb7b4c1044644528f94664441d85cb21b5068fb4->leave($__internal_a985c7186a9e61da6580a98dbb7b4c1044644528f94664441d85cb21b5068fb4_prof);

        
        $__internal_fcea21d6f97a4e2c829c7b3ab01d8e028b819be0bbfbd7ab29c1706bdcf4c667->leave($__internal_fcea21d6f97a4e2c829c7b3ab01d8e028b819be0bbfbd7ab29c1706bdcf4c667_prof);

    }

    // line 53
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_52db725da73fc46c404e16bd16084adfaff30ea526733cc97beecdead5f04b16 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_52db725da73fc46c404e16bd16084adfaff30ea526733cc97beecdead5f04b16->enter($__internal_52db725da73fc46c404e16bd16084adfaff30ea526733cc97beecdead5f04b16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_b2e6399cd9be97d99543c1eb48bf07b986b5ebfc537b371dd92289ae4b6db734 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2e6399cd9be97d99543c1eb48bf07b986b5ebfc537b371dd92289ae4b6db734->enter($__internal_b2e6399cd9be97d99543c1eb48bf07b986b5ebfc537b371dd92289ae4b6db734_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_b2e6399cd9be97d99543c1eb48bf07b986b5ebfc537b371dd92289ae4b6db734->leave($__internal_b2e6399cd9be97d99543c1eb48bf07b986b5ebfc537b371dd92289ae4b6db734_prof);

        
        $__internal_52db725da73fc46c404e16bd16084adfaff30ea526733cc97beecdead5f04b16->leave($__internal_52db725da73fc46c404e16bd16084adfaff30ea526733cc97beecdead5f04b16_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  166 => 53,  149 => 48,  132 => 10,  114 => 8,  102 => 54,  100 => 53,  94 => 49,  92 => 48,  57 => 16,  52 => 14,  45 => 11,  43 => 10,  38 => 8,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <title>{% block title %}Event!{% endblock %}</title>
    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\"> {% block stylesheets %}{% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />


<link rel=\"stylesheet\" href=\"{{ asset('css/stylesheet.css') }}\" />

        <link rel=\"stylesheet\" href=\"{{ asset('stylesheet.css') }}\" />
    
</head>

<body>
    <nav class=\"navbar navbar-default\">
        <div class=\"container\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\" href=\"#\">Event List</a>
            </div>
            <div id=\"navbar\" class=\"collapse navbar-collapse\">
                <ul class=\"nav navbar-nav\">
                    <li><a href=\"/\">Home</a></li>
                    <li><a href=\"/event/create\">Add an event</a></li>

                   
                   

                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
    </nav>
    <div class=\"container\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                {% block body %}{% endblock %}
            </div>
        </div>
    </div>
    <!-- /.container -->
    {% block javascripts %}{% endblock %}
</body>

</html>", "base.html.twig", "C:\\xampp\\htdocs\\event\\app\\Resources\\views\\base.html.twig");
    }
}
