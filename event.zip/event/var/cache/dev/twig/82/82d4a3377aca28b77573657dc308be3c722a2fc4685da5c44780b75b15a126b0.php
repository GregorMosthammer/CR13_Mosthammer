<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_c78883b0a794df95bdc741371f79e94d9f33e13589dce19f76379b9c0a0f1d06 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_861975c18a495dec1ca683dad6aedc8fe138a3c34f0389f82d7cb6bfa7a15cbb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_861975c18a495dec1ca683dad6aedc8fe138a3c34f0389f82d7cb6bfa7a15cbb->enter($__internal_861975c18a495dec1ca683dad6aedc8fe138a3c34f0389f82d7cb6bfa7a15cbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_160fc6eff8f72f0581a85681279651bf3ebf5f18b11d7d4da97e3bb41f078625 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_160fc6eff8f72f0581a85681279651bf3ebf5f18b11d7d4da97e3bb41f078625->enter($__internal_160fc6eff8f72f0581a85681279651bf3ebf5f18b11d7d4da97e3bb41f078625_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_861975c18a495dec1ca683dad6aedc8fe138a3c34f0389f82d7cb6bfa7a15cbb->leave($__internal_861975c18a495dec1ca683dad6aedc8fe138a3c34f0389f82d7cb6bfa7a15cbb_prof);

        
        $__internal_160fc6eff8f72f0581a85681279651bf3ebf5f18b11d7d4da97e3bb41f078625->leave($__internal_160fc6eff8f72f0581a85681279651bf3ebf5f18b11d7d4da97e3bb41f078625_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_f0a9247d71cac4f52ad043d244631b025792262af54864f07f2e1738b442ca52 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f0a9247d71cac4f52ad043d244631b025792262af54864f07f2e1738b442ca52->enter($__internal_f0a9247d71cac4f52ad043d244631b025792262af54864f07f2e1738b442ca52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_7487d2ef9eb51b8ceea9f7dbbe1de9340940d81b4862c7d11a22b60bbeb141a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7487d2ef9eb51b8ceea9f7dbbe1de9340940d81b4862c7d11a22b60bbeb141a0->enter($__internal_7487d2ef9eb51b8ceea9f7dbbe1de9340940d81b4862c7d11a22b60bbeb141a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7487d2ef9eb51b8ceea9f7dbbe1de9340940d81b4862c7d11a22b60bbeb141a0->leave($__internal_7487d2ef9eb51b8ceea9f7dbbe1de9340940d81b4862c7d11a22b60bbeb141a0_prof);

        
        $__internal_f0a9247d71cac4f52ad043d244631b025792262af54864f07f2e1738b442ca52->leave($__internal_f0a9247d71cac4f52ad043d244631b025792262af54864f07f2e1738b442ca52_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_3c013d859d60db13879be2885d124d5c4c8bad0c8d28b2c57d417190c1038807 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c013d859d60db13879be2885d124d5c4c8bad0c8d28b2c57d417190c1038807->enter($__internal_3c013d859d60db13879be2885d124d5c4c8bad0c8d28b2c57d417190c1038807_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_894a867f0f6036cc50c1f4f6dc9ee1c222d493ff06ba2ae12cf082865f9bb483 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_894a867f0f6036cc50c1f4f6dc9ee1c222d493ff06ba2ae12cf082865f9bb483->enter($__internal_894a867f0f6036cc50c1f4f6dc9ee1c222d493ff06ba2ae12cf082865f9bb483_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_894a867f0f6036cc50c1f4f6dc9ee1c222d493ff06ba2ae12cf082865f9bb483->leave($__internal_894a867f0f6036cc50c1f4f6dc9ee1c222d493ff06ba2ae12cf082865f9bb483_prof);

        
        $__internal_3c013d859d60db13879be2885d124d5c4c8bad0c8d28b2c57d417190c1038807->leave($__internal_3c013d859d60db13879be2885d124d5c4c8bad0c8d28b2c57d417190c1038807_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2424fb61f4f25878e17583a9428b506fe273c51c9d64bd6ce33cca4feb9a2ab5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2424fb61f4f25878e17583a9428b506fe273c51c9d64bd6ce33cca4feb9a2ab5->enter($__internal_2424fb61f4f25878e17583a9428b506fe273c51c9d64bd6ce33cca4feb9a2ab5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_7f906fbe7b3340eba1ed98bd2a6bf2baa1ad6cbefb9ed064c36d9af76167d1b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f906fbe7b3340eba1ed98bd2a6bf2baa1ad6cbefb9ed064c36d9af76167d1b3->enter($__internal_7f906fbe7b3340eba1ed98bd2a6bf2baa1ad6cbefb9ed064c36d9af76167d1b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_7f906fbe7b3340eba1ed98bd2a6bf2baa1ad6cbefb9ed064c36d9af76167d1b3->leave($__internal_7f906fbe7b3340eba1ed98bd2a6bf2baa1ad6cbefb9ed064c36d9af76167d1b3_prof);

        
        $__internal_2424fb61f4f25878e17583a9428b506fe273c51c9d64bd6ce33cca4feb9a2ab5->leave($__internal_2424fb61f4f25878e17583a9428b506fe273c51c9d64bd6ce33cca4feb9a2ab5_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\event\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
